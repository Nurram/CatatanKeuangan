package com.nurram.project.catatankeuangan

import com.nurram.project.catatankeuangan.db.Record

class GraphModel(
    val date: String,
    val records: MutableList<Record>
)